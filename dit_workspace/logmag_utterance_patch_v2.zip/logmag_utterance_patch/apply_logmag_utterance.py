#!/usr/bin/env python3
"""Safely add noisy-conditioned utterance z-score for log_magnitude to DiT.

Run from dit_workspace:
  python /tmp/logmag_utterance_patch/apply_logmag_utterance.py --root . --show-diff
  python /tmp/logmag_utterance_patch/apply_logmag_utterance.py --root . --apply

Targeted in-place code changes; refuse unfamiliar sources; backup before writing.
"""
from __future__ import annotations

import argparse
import ast
import difflib
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path


def active_hits(src: str, before: str) -> list[re.Match]:
    """Find real-code occurrences while excluding commented historical blocks.

    Supports both complete lines and mid-line anchors (e.g. `kind not in ...`).
    Still rejects duplicate active definitions or unrecognized source changes.
    """
    result = []
    for match in re.finditer(re.escape(before), src):
        line_start = src.rfind("\n", 0, match.start()) + 1
        prefix = src[line_start:match.start()]
        if prefix.lstrip().startswith("#"):
            continue
        result.append(match)
    return result


def replace_exact(src: str, before: str, after: str, label: str) -> str:
    hits = active_hits(src, before)
    if len(hits) != 1:
        raise ValueError(f"{label}: expected exactly one active anchor, "
                         f"found {len(hits)}; please merge manually")
    hit = hits[0]
    return src[:hit.start()] + after + src[hit.end():]


def patch_spectral(src: str) -> str:
    if 'def _logmag_noisy_stats(' in src:
        if 'normalization == "utterance"' in src and 'def encode_pair(' in src:
            return src  # already installed
        raise ValueError('Detected customized partial logmag normalization; inspect manually')
    required = (
        'class SpectralRepresentation(',
        'def encode(self, waveform)',
        'def to_spectrum(self, representation, noisy_phase=None)',
        'if self.type == "log_magnitude":',
        'def decode(self, representation, length, noisy_phase=None',
    )
    for snippet in required:
        if snippet not in src:
            raise ValueError(f'spectral.py missing known anchor {snippet!r}; manual merge required')

    src = replace_exact(
        src,
        '    def __init__(self, type="complex_ri", phase_source="noisy", **kwargs):',
        '    def __init__(self, type="complex_ri", phase_source="noisy", '
        'normalization="none", utterance_std_floor=1e-3, **kwargs):',
        'spectral constructor',
    )
    src = replace_exact(
        src,
        '        self.type, self.phase_source = type, phase_source\n',
        '        self.type, self.phase_source = type, phase_source\n'
        '        self.normalization = str(normalization)\n'
        '        self.utterance_std_floor = float(utterance_std_floor)\n'
        '        if self.utterance_std_floor <= 0:\n'
        '            raise ValueError("utterance_std_floor must be positive")\n'
        '        if self.normalization not in ("none", "utterance"):\n'
        '            raise ValueError("Spectral z-score supports none or utterance")\n'
        '        if self.normalization == "utterance" and type != "log_magnitude":\n'
        '            raise ValueError("Spectral utterance z-score currently requires log_magnitude")\n',
        'spectral normalization attributes',
    )
    src = replace_exact(
        src,
        '        if self.type == "log_magnitude":\n'
        '            return torch.log(spectrum.abs() + self.eps)[:, None]\n',
        '        if self.type == "log_magnitude":\n'
        '            value = torch.log(spectrum.abs() + self.eps)\n'
        '            if self.normalization == "utterance":\n'
        '                mu, std = self._logmag_noisy_stats(value)\n'
        '                value = (value - mu) / std\n'
        '            return value[:, None]\n',
        'log_magnitude encode',
    )
    addition = '''    def _logmag_noisy_stats(self, noisy_log):
        """Noisy-only [B,1,1] stats, separate for each batch item."""
        mean = noisy_log.mean(dim=(-2, -1), keepdim=True)
        std = noisy_log.std(dim=(-2, -1), unbiased=False,
                            keepdim=True).clamp_min(self.utterance_std_floor)
        return mean, std

    def encode_pair(self, clean_waveform, noisy_waveform):
        """Shared noisy-derived stats; essential for supervised training."""
        if clean_waveform.shape != noisy_waveform.shape:
            raise ValueError("Clean/noisy waveform shapes differ")
        if self.type != "log_magnitude" or self.normalization != "utterance":
            return self.encode(clean_waveform), self.encode(noisy_waveform)
        clean_log = torch.log(self.stft(clean_waveform).abs() + self.eps)
        noisy_log = torch.log(self.stft(noisy_waveform).abs() + self.eps)
        mu, std = self._logmag_noisy_stats(noisy_log)
        return ((clean_log - mu) / std)[:, None], ((noisy_log - mu) / std)[:, None]

'''
    src = replace_exact(
        src,
        '    def to_spectrum(self, representation, noisy_phase=None):\n',
        addition + '    def to_spectrum(self, representation, noisy_phase=None, noisy_waveform=None):\n',
        'spectral stats methods and to_spectrum signature',
    )

    # Support noisy-phase reconstruction for log_magnitude even if WaveformSampler
    # does not explicitly pass a phase tensor.
    src = replace_exact(
        src,
        '        if noisy_phase is None or noisy_phase.shape != representation[:, 0].shape:\n',
        '        if noisy_phase is None and noisy_waveform is not None:\n'
        '            noisy_phase = self.stft(noisy_waveform.float()).angle()\n'
        '        if noisy_phase is None or noisy_phase.shape != representation[:, 0].shape:\n',
        'noisy phase fallback',
    )

    src = replace_exact(
        src,
        '        if self.type == "log_magnitude":\n'
        '            # log magnitude may be negative; exp maps it back to positive magnitude.\n'
        '            log_mag = representation[:, 0].float().clamp(-30.0, 30.0)\n'
        '            magnitude = (torch.exp(log_mag) - self.eps).clamp_min(0)\n'
        '            return torch.polar(magnitude, noisy_phase)\n',
        '        if self.type == "log_magnitude":\n'
        '            log_mag = representation[:, 0].float()\n'
        '            if self.normalization == "utterance":\n'
        '                if noisy_waveform is None:\n'
        '                    raise ValueError("Utterance log_magnitude decoding requires noisy_waveform")\n'
        '                noisy_log = torch.log(self.stft(noisy_waveform.float()).abs() + self.eps)\n'
        '                if noisy_log.shape != log_mag.shape:\n'
        '                    raise ValueError("Noisy/log_magnitude frame mismatch")\n'
        '                mu, std = self._logmag_noisy_stats(noisy_log)\n'
        '                log_mag = log_mag * std + mu\n'
        '            # Preserve original log-magnitude exp clamp at physical reconstruction.\n'
        '            magnitude = (torch.exp(log_mag.clamp(-30.0, 30.0)) - self.eps).clamp_min(0)\n'
        '            return torch.polar(magnitude, noisy_phase)\n',
        'log_magnitude decoder',
    )
    old_decode_sig = '    def decode(self, representation, length, noisy_phase=None):\n'
    new_decode_sig = '    def decode(self, representation, length, noisy_phase=None, noisy_waveform=None):\n'
    if active_hits(src, old_decode_sig):
        src = replace_exact(src, old_decode_sig, new_decode_sig,
                            'spectral decode signature')
    elif len(active_hits(src, new_decode_sig)) != 1:
        raise ValueError('spectral.py decode signature is not recognized')
    src = replace_exact(
        src,
        '        return self.istft(self.to_spectrum(representation, noisy_phase), length)\n',
        '        return self.istft(self.to_spectrum(\n'
        '            representation, noisy_phase, noisy_waveform=noisy_waveform), length)\n',
        'spectral decode body',
    )
    ast.parse(src)
    return src


def patch_objective(src: str) -> str:
    if 'in ("log_mel", "log_magnitude")' in src:
        return src
    known = 'if getattr(self.representation, "type", None) == "log_mel":'
    if known in src:
        src = replace_exact(
            src, known,
            'if getattr(self.representation, "type", None) in ("log_mel", "log_magnitude"):',
            'shared-stat objective dispatch',
        )
    elif 'if hasattr(self.representation, "encode_pair"):' in src:
        return src
    else:
        old = ('            clean = self.representation.encode(clean_waveform.float())\n'
               '            condition = self.representation.encode(noisy_waveform.float())\n')
        new = ('            if hasattr(self.representation, "encode_pair"):\n'
               '                clean, condition = self.representation.encode_pair(\n'
               '                    clean_waveform.float(), noisy_waveform.float())\n'
               '            else:\n'
               '                clean = self.representation.encode(clean_waveform.float())\n'
               '                condition = self.representation.encode(noisy_waveform.float())\n')
        src = replace_exact(src, old, new, 'objective paired waveform encoding')
    ast.parse(src)
    return src


def patch_config(src: str) -> str:
    if '_validate_mel' not in src:
        # Prior to Mel validation, the Representation class is authoritative.
        return src
    options = [
        'kind not in ("complex_ri", "magnitude", "log_mel")',
        'kind not in ("complex_ri", "magnitude", "log_mel", "log_magnitude")',
    ]
    if options[0] in src:
        src = replace_exact(src, options[0], options[1], 'representation validator')
    elif options[1] not in src:
        raise ValueError('Unrecognized representation type validator; merge manually')
    # Avoid silently accepting unsupported spectral normalization configurations.
    anchor = '    if cond_type == "complex_plus_log_mel":\n'
    guard = '''    if kind == "log_magnitude":
        if cond_type not in ("none", "complex_plus_log_mel"):
            raise ValueError("Unknown log_magnitude conditioning")
        if rep.get("normalization", "none") not in ("none", "utterance"):
            raise ValueError("log_magnitude normalization must be none or utterance")
        if float(rep.get("utterance_std_floor", 1e-3)) <= 0:
            raise ValueError("utterance_std_floor must be > 0")

'''
    # The complex_plus_log_mel auxiliary branch is only compatible with complex_ri
    # in current build_auxiliary_encoder, so reject it for log_magnitude.
    guard = guard.replace('if cond_type not in ("none", "complex_plus_log_mel"):', 'if cond_type != "none":')
    if 'if kind == "log_magnitude":' not in src:
        src = replace_exact(src, anchor, guard + anchor, 'log_magnitude validator')
    ast.parse(src)
    return src


def patch_sampler(src: str) -> str:
    # The Mel extension sampler should forward noisy_waveform to the decoder.
    if 'noisy_waveform=noisy' not in src:
        raise ValueError('WaveformSampler does not forward noisy_waveform; install/fix the Mel sampler first')
    return src  # spectral decoder can derive noisy phase itself when needed


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', default='.', help='dit_workspace directory')
    parser.add_argument('--apply', action='store_true', help='apply after backups; default dry-run')
    parser.add_argument('--show-diff', action='store_true')
    args = parser.parse_args()
    root = Path(args.root).resolve()
    targets = [
        ('dit/representations/spectral.py', patch_spectral),
        ('dit/objectives/regression.py', patch_objective),
        ('dit/utils/config.py', patch_config),
        ('dit/samplers/base.py', patch_sampler),
    ]
    changes = {}
    for rel, fn in targets:
        file = root / rel
        if not file.is_file():
            raise FileNotFoundError(f'Missing required source: {file}')
        original = file.read_text(encoding='utf-8')
        updated = fn(original)
        if updated != original:
            changes[file] = (original, updated)
            print(f'[CHANGE] {rel}')
            if args.show_diff:
                print(''.join(difflib.unified_diff(original.splitlines(True),
                      updated.splitlines(True), fromfile=rel, tofile=rel+' (logmag utterance)')))
        else:
            print(f'[UNCHANGED] {rel}')
    if not args.apply:
        print(f'\nDRY RUN: {len(changes)} file(s). Add --apply to install.')
        return
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    for file, (before, after) in changes.items():
        bak = file.with_name(file.name + f'.bak_logmag_{stamp}')
        shutil.copy2(file, bak)
        file.write_text(after, encoding='utf-8')
        print(f'[SAVED] {file.relative_to(root)}; backup {bak.name}')
    print(f'\nSuccessfully installed; changed {len(changes)} file(s).')


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print(f'ERROR: {e}', file=sys.stderr)
        sys.exit(1)
