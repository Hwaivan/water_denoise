**v2 (2026-11-02):** 修复安装器将 `spectral.py` 注释中的旧构造函数识别为第二个锚点的问题。现在只匹配行首的有效源码；不会删除、覆盖注释代码，也不会跳过对真实重复定义的安全检查。

# Log-Magnitude · Utterance-level Noisy-Conditioned Z-score

This **incremental** patch adds `representation.type: log_magnitude` with `normalization: utterance` to the existing Mel-enabled DiT pipeline. It keeps the old `normalization: none` behavior unchanged and does not alter `complex_ri`, `magnitude`, or `log_mel` internals.

## 1. Install safely

From `/data/huayifan/water_denoise/dit_workspace` after unzipping into `/tmp`:

```bash
python /tmp/logmag_utterance_patch/apply_logmag_utterance.py --root . --show-diff
python /tmp/logmag_utterance_patch/apply_logmag_utterance.py --root . --apply
python -m pytest -q /tmp/logmag_utterance_patch/test_logmag_utterance.py
```

- Dry-run is the default. `--apply` creates per-file timestamped backups (`*.bak_logmag_...`).
- If any known source section has changed in the user workspace, the installer **aborts** instead of blindly replacing source. Inspect and manually merge. It checks `WaveformSampler` already forwards `noisy_waveform=noisy` as required by the previous Mel extension.
- The underlying project may have moved on since the packaged code; the full test suite and a 1-batch end-to-end smoke test are still recommended.

## 2. Configuration

Copy an existing **complete** frame1d Flow YAML, use a new experiment name/output directory and change:

```yaml
representation:
  type: log_magnitude
  phase_source: noisy
  normalization: utterance
  utterance_std_floor: 0.001

model:
  tokenization: frame1d
  # keep your existing depth/hidden_size/num_heads etc.

process:
  type: flow
  noise_convention: real_unit_variance

sampler:
  name: euler
  num_steps: 30
  use_ema: true
```

Do **not** set `representation.mel`, `stats_path` or `normalization: dataset` for this spectral representation. No offline Mel stats are needed. Use the usual `train.py --config ... --num-gpus 1` or ensure the existing `run_train_dit.sh` references the new base config without overriding `representation` values.

## 3. Mathematical contract

Let `C = log(|STFT(clean)| + eps)` and `Y = log(|STFT(noisy)| + eps)`, both `[B, F, T]`. For each item separately, calculate two scalar values:

```python
mean = Y.mean(dim=(-2,-1), keepdim=True)
std = Y.std(dim=(-2,-1), keepdim=True, unbiased=False).clamp_min(1e-3)
C_norm = (C - mean)/std
Y_norm = (Y - mean)/std
```

`RegressionObjective` now calls `encode_pair(clean, noisy)` for both `log_mel` and `log_magnitude`, making the **training labels** consistent with inference. `WaveformSampler` already passes the original noisy waveform; the spectral decoder recomputes `mean/std` from the same noisy segment, computes `pred * std + mean`, exponentiates, uses **noisy phase** and iSTFT. This preserves exactly the baseline `log_magnitude` amplitude/phase reconstruction approach (except normalization, which is reversed).

Note: the model cannot recover clean phase using noisy phase; z-score does not fix this.

## 4. Experiment & edge cases

- This change **requires retraining**; do not resume the original unnormalized/dataset-normalized checkpoint. Keep the old baseline separately.
- For paired 5 s fixed-length files, use the same 5 s segments for training and inference. If training crops from longer waveforms **after** feature encoding, stats may be over a longer region than inference chunk stats; normalize/crop on a consistent segment.
- Do not independently normalize Clean and Noisy, or save mutable per-sample statistics on a shared model object.
- With variable-length padded batches, exclude padded frames when estimating per-item stats.
- Since `log_magnitude` is one real channel, use `real_unit_variance` noise in Score/Flow. Original complex magnitude-compression `alpha/beta` do not apply to `log_magnitude`.
- Tests cover paired statistics, identity reconstruction, old representation compatibility, objective and single-step Flow inference; run the project suite as well.
