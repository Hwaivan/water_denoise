"""Run from dit_workspace: python -m pytest -q /tmp/logmag_utterance_patch/test_logmag_utterance.py"""
from __future__ import annotations

from types import SimpleNamespace

import torch
from torch import nn

from dit.representations.spectral import SpectralRepresentation
from dit.objectives.regression import RegressionObjective


STFT = dict(n_fft=64, win_length=48, hop_length=16, window="hann",
            center=True, normalized=False, onesided=True,
            alpha=0.5, beta=0.15)


def make_rep(kind="log_magnitude", norm="utterance"):
    return SpectralRepresentation(type=kind, phase_source="noisy",
                                  normalization=norm,
                                  utterance_std_floor=1e-3, **STFT)


def pair():
    g = torch.Generator().manual_seed(123)
    noisy = torch.stack((torch.randn(512, generator=g) * 0.04,
                         torch.randn(512, generator=g) * 0.3))
    clean = noisy * 0.75 + torch.randn(noisy.shape, generator=g) * 0.003
    return clean, noisy


def test_logmag_utterance_uses_only_noisy_stats():
    codec = make_rep()
    clean, noisy = pair()
    x, y = codec.encode_pair(clean, noisy)
    assert x.shape == y.shape == (2, 1, 33, 33)
    noisy_log = torch.log(codec.stft(noisy).abs() + codec.eps)
    clean_log = torch.log(codec.stft(clean).abs() + codec.eps)
    mu = noisy_log.mean(dim=(-2, -1), keepdim=True)
    std = noisy_log.std(dim=(-2, -1), keepdim=True, unbiased=False).clamp_min(1e-3)
    torch.testing.assert_close(y[:, 0], (noisy_log-mu)/std)
    torch.testing.assert_close(x[:, 0], (clean_log-mu)/std)
    torch.testing.assert_close(codec.encode(noisy), y)
    torch.testing.assert_close(y.mean(dim=(-2, -1)), torch.zeros(2,1), atol=2e-6, rtol=0)
    torch.testing.assert_close(y.std(dim=(-2, -1), unbiased=False), torch.ones(2,1), atol=2e-6, rtol=0)


def test_logmag_utterance_decode_identity_from_noisy():
    codec = make_rep()
    _, noisy = pair()
    estimate = codec.encode(noisy)
    waveform = codec.decode(estimate, noisy.shape[-1], noisy_waveform=noisy)
    torch.testing.assert_close(waveform, noisy, atol=3e-5, rtol=3e-4)


def test_logmag_none_stays_backward_compatible():
    codec = make_rep(norm="none")
    _, noisy = pair()
    features = codec.encode(noisy)
    expected = torch.log(codec.stft(noisy).abs() + codec.eps)[:, None]
    torch.testing.assert_close(features, expected)
    phase = codec.stft(noisy).angle()
    output = codec.decode(features, noisy.shape[-1], phase)
    torch.testing.assert_close(output, noisy, atol=3e-5, rtol=3e-4)


def test_complex_and_magnitude_modes_unchanged():
    _, noisy = pair()
    for rep_type in ("complex_ri", "magnitude"):
        codec = make_rep(kind=rep_type, norm="none")
        raw = codec.encode(noisy)
        clean, condition = codec.encode_pair(noisy, noisy)
        torch.testing.assert_close(clean, raw)
        torch.testing.assert_close(condition, raw)
        phase = codec.stft(noisy).angle() if rep_type == "magnitude" else None
        output = codec.decode(raw, noisy.shape[-1], phase)
        torch.testing.assert_close(output, noisy, atol=3e-5, rtol=3e-4)


def test_loss_uses_paired_noisy_derived_stats():
    codec = make_rep()
    clean, noisy = pair()

    class ProbeProcess:
        kind = "flow"
        loss_name = "flow_loss"
        def sample_training_pair(self, clean, cond, generator, deterministic):
            self.clean_seen = clean.detach().clone()
            self.cond_seen = cond.detach().clone()
            return SimpleNamespace(state=cond, target=clean,
                                   time=torch.full((clean.shape[0],),0.5),diagnostics={})

    class ToyModel(nn.Module):
        def __init__(self):
            super().__init__()
            self.gain = nn.Parameter(torch.tensor(.2))
        def forward(self, state, condition, time, **kw):
            return self.gain * condition

    process = ProbeProcess()
    objective = RegressionObjective(codec, process, crop_frames=33)
    model = ToyModel()
    loss = objective(model, clean, noisy)["total"]
    assert torch.isfinite(loss)
    loss.backward()
    assert torch.isfinite(model.gain.grad)
    want_clean, want_cond = codec.encode_pair(clean, noisy)
    torch.testing.assert_close(process.clean_seen, want_clean)
    torch.testing.assert_close(process.cond_seen, want_cond)


def test_flow_sampling_decodes_correctly():
    from dit.processes.flow_matching import FlowProcess
    from dit.samplers.flow_ode import FlowODE
    from dit.samplers.base import WaveformSampler

    class IdentityStep(nn.Module):
        def forward(self, state, condition, time, **kw):
            return condition - state

    codec = make_rep()
    _, noisy = pair()
    process = FlowProcess(noise_convention="real_unit_variance", source="gaussian")
    sampler = WaveformSampler(codec, FlowODE(process, num_steps=1, solver="euler"))
    result = sampler.sample_waveform(IdentityStep(), noisy)
    assert result.nfe == 1
    torch.testing.assert_close(result.waveform, noisy, atol=3e-5, rtol=3e-4)
